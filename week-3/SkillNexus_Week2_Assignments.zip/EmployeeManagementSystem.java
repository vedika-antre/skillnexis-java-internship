import java.io.*;
import java.util.*;

class Employee {
    private int id;
    private String name;
    private String department;
    private double salary;

    public Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String toFileString() {
        return id + "," + name + "," + department + "," + salary;
    }

    public static Employee fromFileString(String line) {
        String[] data = line.split(",");

        if (data.length != 4) {
            throw new IllegalArgumentException("Invalid employee data.");
        }

        int id = Integer.parseInt(data[0]);
        String name = data[1];
        String department = data[2];
        double salary = Double.parseDouble(data[3]);

        return new Employee(id, name, department, salary);
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name +
               ", Department: " + department + ", Salary: " + salary;
    }
}

public class EmployeeManagementSystem {
    private static final String FILE_NAME = "employees.txt";
    private static final ArrayList<Employee> employees = new ArrayList<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        loadEmployees();

        while (true) {
            System.out.println("\n===== Employee Management System =====");
            System.out.println("1. Add Employee");
            System.out.println("2. Display Employees");
            System.out.println("3. Save Employees");
            System.out.println("4. Load Employees");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        addEmployee();
                        break;
                    case 2:
                        displayEmployees();
                        break;
                    case 3:
                        saveEmployees();
                        break;
                    case 4:
                        loadEmployees();
                        break;
                    case 5:
                        saveEmployees();
                        System.out.println("Program ended.");
                        sc.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Enter 1 to 5.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private static void addEmployee() {
        try {
            System.out.print("Enter Employee ID: ");
            int id = Integer.parseInt(sc.nextLine());

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            if (name.trim().isEmpty()) {
                throw new IllegalArgumentException("Name cannot be empty.");
            }

            System.out.print("Enter Department: ");
            String department = sc.nextLine();

            if (department.trim().isEmpty()) {
                throw new IllegalArgumentException("Department cannot be empty.");
            }

            System.out.print("Enter Salary: ");
            double salary = Double.parseDouble(sc.nextLine());

            if (salary < 0) {
                throw new IllegalArgumentException("Salary cannot be negative.");
            }

            employees.add(new Employee(id, name, department, salary));
            System.out.println("Employee added successfully.");

        } catch (NumberFormatException e) {
            System.out.println("Invalid ID or salary. Please enter a valid number.");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid input: " + e.getMessage());
        }
    }

    private static void displayEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employee records found.");
            return;
        }

        System.out.println("\n--- Employee Records ---");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    private static void saveEmployees() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Employee employee : employees) {
                bw.write(employee.toFileString());
                bw.newLine();
            }
            System.out.println("Employee data saved to " + FILE_NAME);
        } catch (IOException e) {
            System.out.println("Error while saving data: " + e.getMessage());
        }
    }

    private static void loadEmployees() {
        employees.clear();

        File file = new File(FILE_NAME);

        if (!file.exists()) {
            System.out.println("No existing employee file found. Starting with empty records.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;

            while ((line = br.readLine()) != null) {
                try {
                    employees.add(Employee.fromFileString(line));
                } catch (Exception e) {
                    System.out.println("Skipped invalid record: " + line);
                }
            }

            System.out.println("Employee data loaded successfully.");

        } catch (IOException e) {
            System.out.println("Error while loading data: " + e.getMessage());
        }
    }
}
