import java.io.*;
import java.util.*;

public class WordFrequency {
    public static void main(String[] args) {
        String inputFile = "input.txt";
        String outputFile = "word_frequency.txt";

        Map<String, Integer> frequency = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] words = line.toLowerCase().split("[^a-zA-Z0-9]+");

                for (String word : words) {
                    if (!word.isEmpty()) {
                        frequency.put(word, frequency.getOrDefault(word, 0) + 1);
                    }
                }
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
                for (Map.Entry<String, Integer> entry : frequency.entrySet()) {
                    bw.write(entry.getKey() + " : " + entry.getValue());
                    bw.newLine();
                }
            }

            System.out.println("Word frequency calculated successfully.");
            System.out.println("Output written to " + outputFile);

        } catch (FileNotFoundException e) {
            System.out.println("Error: input.txt file was not found.");
        } catch (IOException e) {
            System.out.println("Error while reading or writing the file: " + e.getMessage());
        }
    }
}
